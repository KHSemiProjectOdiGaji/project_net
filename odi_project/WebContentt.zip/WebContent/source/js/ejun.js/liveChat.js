
// chatPage
function createChatRoom(){
  
  if(document.querySelector("#create-chat-box").style.display=="none"){
    document.querySelector("#create-chat-box").style.display="block"

  }else
    document.querySelector('#create-chat-box').style.display="none"
}
